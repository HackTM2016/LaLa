angular.module('musicapp.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout, $state) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});



    $scope.activeState = $state.current.name;

    $scope.$on('$stateChangeStart',
      function(event, toState, toParams, fromState, fromParams){
        $scope.activeState = toState.name;
      });

    $scope.selectedLocation = {};
})

.controller('LocationsCtrl', function($scope, $state, $ionicHistory) {
  $scope.locations = [
    { name: 'KFC FoodCourt', distance: 40, id: 1, image: "https://pbs.twimg.com/profile_images/1798607000/KFC_LOGO.gif" },
    { name: 'PizzaHut Iulius Mall', distance: 90, id: 2, image: "http://dial4sms.co.in/wp-content/uploads/2015/06/PIZZAHUT.jpg" },
    { name: 'Adidas Iulius Mall', id: 3, distance: 210, image: "http://magic-marketing.ro/images/blog-masonry/adidas-logo.jpg" }
  ];

    $scope.selectLocation = function(location) {
      $ionicHistory.nextViewOptions({
        disableBack: true
      });
      $scope.selectedLocation.id = location.id;
      $scope.selectedLocation.name = location.name;
      $scope.selectedLocation.image = location.image;
      $scope.selectedLocation.distance = location.distance;
      $state.go("app.playlists", {notify: false});
    }
})

.controller('PlayingCtrl', function($scope, Youtube, $timeout, $interval) {

    var myPlaylist = ["CkA4xcIAvuw", "yjuv2qMAzC8", "oyEuk8j8imI", "4nWw4wYAVyc", "nvGDscMftN8", "cVo1-oJRJ6U", "6Fot9g9YKyw", "NlXTv5Ondgs"];

    $scope.songs = [];
    Youtube.getVideosInfo(myPlaylist.toString()).then(function(data) {
      $scope.songs = data.data.items;
      $scope.currentSong = $scope.songs[2];
      $scope.songs.forEach(function(song) {

      });
    });
    console.log('videos');

    $scope.currentSong = {};
    $scope.currentTime = 50+ "%";
    $interval(function() {
      $scope.currentTime = Math.floor(Math.random() * 100) + "%";
    }, 1000);

    var msgTimeout;

    $scope.tapSong = function(songId) {

      $scope.messageId = songId;
      if(msgTimeout) {
        $timeout.cancel(msgTimeout);
      }
      msgTimeout = $timeout(function() {
        $scope.messageId = null;
      }, 1500);
      console.log('tap');
      $scope.text = "hold";

    };

    $scope.voteSong = function(song) {
      console.log('voteSong');
      song.voted = !song.voted;
    };

    $scope.history = [
      { title: 'H1', id: 1 },
      { title: 'Chill', id: 2 },
      { title: 'Rap', id: 3 },
      { title: 'Cowbell', id: 4 },
      { title: 'H5', id: 5 }
    ];

    $scope.options = {
      loop: false,
      pager: true,
      initialSlide: 1,
      direction: 'horizontal',
      speed: 500
    };


});
