angular.module('musicapp.services', [])

  .factory('Youtube', function($http) {

    var apiKey = "AIzaSyC-y_YPMT6OUmNqqOHn1X8ozLglrAOd_Og";

    return {

     getVideoInfo: function(videoId) {
       return $http.get("https://www.googleapis.com/youtube/v3/videos", {params: {id: [videoId], part: "snippet", key: apiKey} });
     },
     getVideosInfo: function(videosList) {
       return $http.get("https://www.googleapis.com/youtube/v3/videos", {params: {id: [videosList], part: "snippet", key: apiKey} });
     }
   }

  });
